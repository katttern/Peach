-- Step 1: load the dt=... partitions from S3.
MSCK REPAIR TABLE payment_events
